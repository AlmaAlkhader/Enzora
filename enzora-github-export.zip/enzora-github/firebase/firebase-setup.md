# Firebase Setup

Enzora uses Firebase for authentication, Firestore database, and push messaging. Follow these steps to connect the mobile app to your own Firebase project.

> **Security Warning:** Never commit `serviceAccountKey.json`, `google-services.json`, `GoogleService-Info.plist`, or any other file containing a private key or service account credential to version control. These files are listed in the root `.gitignore`, but always double-check before pushing.

## 1. Create a Firebase Project

1. Go to [console.firebase.google.com](https://console.firebase.google.com) and click **Add project**.
2. Give the project a name (e.g. `enzora-prod`) and follow the setup wizard.

## 2. Enable Authentication

1. In the Firebase console, navigate to **Authentication → Sign-in method**.
2. Enable **Email/Password**.
3. (Optional) Enable additional providers such as Google Sign-In.

## 3. Enable Firestore

1. Navigate to **Firestore Database** and click **Create database**.
2. Start in **production mode** and choose a region close to your users.
3. Deploy security rules — a starter ruleset will be added to this folder in a future update.

## 4. Register the Mobile App

1. In **Project settings → Your apps**, click the iOS and/or Android icon to add a new app.
2. For iOS: download `GoogleService-Info.plist` — **do not commit this file**.
3. For Android: download `google-services.json` — **do not commit this file**.
4. For Expo managed workflow, copy the Firebase web config values (API key, auth domain, etc.) into your `.env` file (see `app/README.md`).

## 5. Configure Environment Variables

Create `app/.env` with the values from your Firebase web app config:

```env
EXPO_PUBLIC_FIREBASE_API_KEY=AIza...
EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
EXPO_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
EXPO_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abc123
```

This file is git-ignored. Never commit it.

## 6. Push Notifications (Optional)

Enzora supports push notifications via Expo Notifications + Firebase Cloud Messaging.

1. In the Firebase console, navigate to **Project settings → Cloud Messaging**.
2. Copy the **Server key** and add it to Expo's push notification service via `eas credentials` or the Expo dashboard.

## Planned Contents

| File | Description |
|---|---|
| `firestore.rules` | Firestore security rules |
| `firestore.indexes.json` | Composite index definitions |
| `functions/` | Cloud Functions source (if used) |

These files will be added as the backend matures.
