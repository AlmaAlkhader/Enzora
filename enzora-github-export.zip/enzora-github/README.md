# Enzora

Enzora is an AI-powered wound-care companion that helps patients monitor healing, receive personalised care tips, and stay connected with their care team — from a smart bandage sensor to a mobile app.

## Repository Structure

```
enzora/
├── app/          # React Native mobile app (Expo)
├── website/      # Marketing & web presence
├── docs/         # Screenshots, diagrams, and design assets
├── hardware/     # Hardware schematics and firmware notes
├── firebase/     # Firebase project setup and security rules
└── .gitignore
```

## Getting Started

### Mobile App

```bash
cd app
npm install
npx expo start
```

See [`app/README.md`](app/README.md) for full install instructions, environment variable setup, and build guidance.

### Website

See the `website/` folder for the web presence. Refer to the README inside that folder for its own setup steps.

## Hardware

The Enzora smart bandage communicates wound status to the mobile app via BLE. See [`hardware/README.md`](hardware/README.md) for an overview of the hardware design.

## Firebase

Enzora uses Firebase for authentication and data storage. See [`firebase/firebase-setup.md`](firebase/firebase-setup.md) for setup instructions.

## Contributing

1. Fork the repository and create a feature branch.
2. Make your changes, add tests where applicable.
3. Open a pull request against `main`.

Please review the security notes in `app/README.md` before committing — never push private keys or `.env` files.

## License

Proprietary — all rights reserved.
