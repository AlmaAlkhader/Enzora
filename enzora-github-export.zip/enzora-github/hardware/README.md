# Hardware — Enzora Smart Bandage

This folder will contain schematics, firmware source, and assembly notes for the Enzora smart bandage sensor.

## Overview

The Enzora smart bandage is a lightweight, disposable sensor patch that monitors wound status in real time. It communicates wirelessly with the Enzora mobile app to give patients and clinicians an up-to-date picture of healing progress.

## Planned Contents

| Folder / File | Description |
|---|---|
| `schematics/` | PCB schematics and Gerber files |
| `firmware/` | Microcontroller firmware source code |
| `bom.csv` | Bill of materials |
| `assembly-guide.md` | Step-by-step assembly instructions |
| `ble-protocol.md` | BLE service/characteristic definitions used to communicate with the mobile app |

## Status

Hardware design is in progress. This folder is a placeholder — files will be added as the hardware design matures.

## Contact

For hardware-related questions, reach out to the engineering team.
