# Enzora — Mobile App

Enzora is an AI-powered wound-care companion app built with React Native and Expo. It helps users monitor wound healing progress, receive personalised care tips, and stay connected with their care team.

## Tech Stack

- **Framework:** React Native + Expo (SDK 54)
- **Navigation:** Expo Router (file-based routing)
- **State / data fetching:** TanStack React Query
- **Auth & backend:** Firebase (Auth + Firestore)
- **Push notifications:** Expo Notifications
- **Localisation:** i18next / react-i18next
- **Language:** TypeScript (strict)

## Prerequisites

- Node.js 18+ and npm (or yarn / pnpm)
- [Expo CLI](https://docs.expo.dev/more/expo-cli/) — installed automatically via `npx expo`
- A physical device or simulator with **Expo Go** installed (or a custom dev build)
- A Firebase project with Auth and Firestore enabled (see [Firebase setup](../firebase/firebase-setup.md))

## Install & Run

```bash
# 1. Install dependencies
cd app
npm install

# 2. Start the Expo development server
npx expo start
```

Scan the QR code in your terminal with the **Expo Go** app on iOS or Android, or press `i` / `a` to open the iOS simulator or Android emulator.

Other useful commands:

```bash
npx expo start --ios       # open in iOS simulator directly
npx expo start --android   # open in Android emulator directly
npx expo start --web       # open in browser (web preview)
npm run typecheck          # TypeScript type-check without building
```

## Environment Variables

Create a `.env` file in this folder (it is git-ignored). At minimum you need the Firebase configuration values:

```env
EXPO_PUBLIC_FIREBASE_API_KEY=your_api_key
EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
EXPO_PUBLIC_FIREBASE_PROJECT_ID=your_project_id
EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
EXPO_PUBLIC_FIREBASE_APP_ID=your_app_id
```

All `EXPO_PUBLIC_` variables are bundled into the JS bundle at build time and are safe to use in client code. They are **not** secret.

## Firebase Notes

- See [`../firebase/firebase-setup.md`](../firebase/firebase-setup.md) for full setup instructions.
- Enable **Email/Password** authentication in the Firebase console under Authentication → Sign-in method.
- Enable **Firestore** and deploy the security rules before shipping.

## EAS Build (optional)

To create a production build via Expo Application Services:

```bash
npm install -g eas-cli
eas login
eas build --platform ios    # or android
```

You will need an [Expo account](https://expo.dev) and, for iOS, an Apple Developer account.

## Security Warning

**Never commit private keys, service account JSON files, or `.env` files to version control.** The root `.gitignore` covers the most common patterns, but always double-check before pushing.

## Project Structure

```
app/
├── app/              # Expo Router screens and layouts
│   ├── (tabs)/       # Bottom-tab screens
│   ├── wound/        # Wound detail and new-wound flows
│   └── _layout.tsx   # Root layout
├── assets/           # Images and other static assets
├── components/       # Reusable UI components
├── constants/        # Colours, layout constants
├── contexts/         # React contexts (app-wide state)
├── hooks/            # Custom hooks
├── lib/              # Business logic, Firebase helpers, AI client
├── app.json          # Expo config (static)
├── app.config.js     # Expo config (dynamic, injects env vars)
├── eas.json          # EAS build profiles
└── tsconfig.json     # TypeScript config
```
